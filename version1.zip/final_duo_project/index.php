<?php
header("Location: final_project/page/login.php");
exit();
