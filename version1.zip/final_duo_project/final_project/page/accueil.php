<?php
session_start();
include("../function/function.php");

if (empty($_SESSION["etu"])) {
    header("Location: login.php");
    exit;
}

// Achat d'un produit : on redirige tout de suite après (Post/Redirect/Get)
// pour éviter qu'un rechargement de la page ne rachète le produit.
if (!empty($_GET['id_produit_membre'])) {
    acheter_produit($_GET['id_produit_membre']);
    header("Location: accueil.php");
    exit;
}

$voir = show_all_product();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <nav class="navbar navbar-dark bg-dark mb-4">
        <div class="container">
            <span class="navbar-brand mb-0 h1">Cantine ITU</span>
            <a href="vendre.php" class="btn btn-outline-light">Mes produits à vendre</a>
        </div>
    </nav>

    <div class="container">
        <h1 class="mb-4">Produits disponibles</h1>

        <table class="table table-striped table-bordered align-middle bg-white">
            <thead class="table-dark">
                <tr>
                    <th>ID produit membre</th>
                    <th>Nom</th>
                    <th>Quantité disponible</th>
                    <th>Prix</th>
                    <th>Catégorie</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($voir as $row) { ?>
                <tr>
                    <td><?php echo $row['id_produit_membre']; ?></td>
                    <td><?php echo $row['nom']; ?></td>
                    <td><?php echo $row['quantite_dispo']; ?></td>
                    <td><?php echo $row['prix_vente']; ?></td>
                    <td><?php echo $row['nom_categorie']; ?></td>
                    <td>
                        <a href="accueil.php?id_produit_membre=<?php echo $row['id_produit_membre']; ?>" class="btn btn-sm btn-success">
                            Acheter
                        </a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
