<?php
session_start();
include("../function/function.php");
$sign = isset($_GET["sign"]) ? (int)$_GET["sign"] : 0;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <div class="container" style="max-width: 400px; margin-top: 80px;">
        <h1 class="mb-4 text-center">Connexion</h1>

        <form action="../traitement/trait_etu.php" method="post" class="card p-4 shadow-sm">
            <?php if ($sign == 0) { ?>
                <div class="mb-3">
                    <label for="etu" class="form-label">Numéro ITU</label>
                    <input type="text" id="etu" name="etu" class="form-control" required>
                </div>
            <?php } else { ?>
                <p class="text-success">Bienvenue ! Il ne reste plus qu'à entrer votre nom.</p>
                <div class="mb-3">
                    <label for="nom" class="form-label">Nom</label>
                    <input type="text" id="nom" name="nom" class="form-control" required>
                </div>
            <?php } ?>
            <button type="submit" class="btn btn-primary w-100">Valider</button>
        </form>
    </div>

    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
