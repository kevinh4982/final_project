<?php
session_start();

if (empty($_SESSION["etu"])) {
    header("Location: login.php");
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$max = isset($_GET['max']) ? (int)$_GET['max'] : 0;

if ($id == 0) {
    header("Location: vendre.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vendre un produit</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <div class="container" style="max-width: 400px; margin-top: 80px;">
        <h1 class="mb-4">Vendre un produit</h1>

        <form action="../traitement/trait_sale.php" method="post" class="card p-4 shadow-sm">
            <input type="hidden" name="id_produit_membre" value="<?php echo $id; ?>">

            <div class="mb-3">
                <label for="sale" class="form-label">Quantité à vendre (max <?php echo $max; ?>)</label>
                <input type="number" id="sale" name="sale" class="form-control" min="1" max="<?php echo $max; ?>" required>
            </div>

            <button type="submit" class="btn btn-warning w-100">Valider la vente</button>
        </form>
    </div>

    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
