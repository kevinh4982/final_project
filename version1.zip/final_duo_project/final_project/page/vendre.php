<?php
session_start();
include("../function/function.php");

if (empty($_SESSION["etu"])) {
    header("Location: login.php");
    exit;
}

$etu = $_SESSION["etu"];
$resultat = get_all_mine_produits($etu);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes produits</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <nav class="navbar navbar-dark bg-dark mb-4">
        <div class="container">
            <span class="navbar-brand mb-0 h1">Cantine ITU</span>
            <a href="accueil.php" class="btn btn-outline-light">Retour à l'accueil</a>
        </div>
    </nav>

    <div class="container">
        <h1 class="mb-4">Mes produits à vendre</h1>

        <table class="table table-striped table-bordered align-middle bg-white" width="1000">
            <thead class="table-dark">
                <tr>
                    <th>id_membre</th>
                    <th>numero_itu</th>
                    <th>nom_produit</th>
                    <th>prix_vente</th>
                    <th>quantite_dispo</th>
                    <th>Vendre</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($resultat as $r) { ?>
                <tr>
                    <td><?=$r["id_membre"]?></td>
                    <td><?=$r["numero_itu"]?></td>
                    <td><?=$r["nom_produit"]?></td>
                    <td><?=$r["prix_vente"]?></td>
                    <td><?=$r["quantite_dispo"]?></td>
                    <td>
                        <a href="saling.php?id=<?=$r['id_produit_membre']?>&max=<?=$r['quantite_dispo']?>" class="btn btn-sm btn-warning">
                            Vendre
                        </a>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>

    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
