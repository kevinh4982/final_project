<?php
include("connect.php");

function get_all_lines($sql){
    $req = mysqli_query(dbconnect(), $sql);
    if (!$req) {
        die('Erreur SQL : ' . mysqli_error(dbconnect()));
    }
    $result = array();
    while ($line = mysqli_fetch_assoc($req)) {
        $result[] = $line;
    }
    mysqli_free_result($req);
    return $result;
}

function get_one_line($sql){
    $req = mysqli_query(dbconnect(), $sql);
    if (!$req) {
        die('Erreur SQL : ' . mysqli_error(dbconnect()));
    }
    $result = mysqli_fetch_assoc($req);
    mysqli_free_result($req);
    return $result;
}

function get_etu($etu){
    $etu = (int)$etu;
    $sql = "SELECT * FROM membre WHERE numero_itu = $etu";
    return get_one_line($sql);
}

function add_etu($setu){
    $conn = dbconnect();
    $setu = (int)$setu;
    $sql = "INSERT INTO membre (numero_itu) VALUES ($setu)";
    return mysqli_query($conn, $sql);
}

function sign_up_etu($nom, $etu){
    $conn = dbconnect();
    $nom_safe = mysqli_real_escape_string($conn, $nom);
    $etu = (int)$etu;
    $sql = "UPDATE membre SET nom = '$nom_safe' WHERE numero_itu = $etu";
    return mysqli_query($conn, $sql);
}

function get_all_mine_produits($etu){
    $etu = (int)$etu;
    $sql = "SELECT p.id_produit_membre, m.id_membre, m.numero_itu, pr.nom AS nom_produit,
                   p.prix_vente, p.quantite_dispo
            FROM membre m
            JOIN produit_membre p ON p.id_membre = m.id_membre
            JOIN produit pr ON pr.id_produit = p.id_produit
            WHERE m.numero_itu = $etu";
    return get_all_lines($sql);
}

function show_all_product(){
    $sql = 'SELECT produit_membre.id_produit_membre, produit.nom, produit_membre.quantite_dispo,
    produit_membre.prix_vente, categorie.nom_categorie
    FROM produit_membre
    JOIN produit ON produit_membre.id_produit = produit.id_produit
    JOIN categorie ON produit.id_categorie = categorie.id_categorie
    WHERE produit_membre.quantite_dispo > 0;';

    return get_all_lines($sql);
}

function acheter_produit($id_produit_membre){
    $conn = dbconnect();
    $id_produit_membre = (int)$id_produit_membre;

    $sql = "SELECT quantite_dispo FROM produit_membre WHERE id_produit_membre = $id_produit_membre";
    $result = get_one_line($sql);

    if ($result && $result['quantite_dispo'] > 0){
        $sql = "UPDATE produit_membre SET quantite_dispo = quantite_dispo - 1 WHERE id_produit_membre = $id_produit_membre";
        $req1 = mysqli_query($conn, $sql);
        if (!$req1){
            die('Erreur SQL update produit_membre : ' . mysqli_error($conn));
        }
        $sql = "INSERT INTO vente (date_vente, heure, id_produit_membre, quantite) VALUES (CURDATE(), CURTIME(), $id_produit_membre, 1)";
        $req2 = mysqli_query($conn, $sql);
        if (!$req2){
            die('Erreur SQL insert vente : ' . mysqli_error($conn));
        }
        return true;
    } else {
        return false;
    }
}

// Permet à un membre de retirer une quantité de son stock (vente réalisée hors application)
function Saling_my_produits($id_produit_membre, $quantite){
    $conn = dbconnect();
    $id_produit_membre = (int)$id_produit_membre;
    $quantite = (int)$quantite;

    if ($quantite <= 0){
        return false;
    }

    $sql = "SELECT quantite_dispo FROM produit_membre WHERE id_produit_membre = $id_produit_membre";
    $result = get_one_line($sql);

    if ($result && $result['quantite_dispo'] >= $quantite){
        $sql = "UPDATE produit_membre SET quantite_dispo = quantite_dispo - $quantite WHERE id_produit_membre = $id_produit_membre";
        $req = mysqli_query($conn, $sql);
        if (!$req){
            die('Erreur SQL update produit_membre : ' . mysqli_error($conn));
        }
        return true;
    } else {
        return false;
    }
}
