# ETU004982
## login.php(ETU004982)
### html
#### Formulaire
    -Champ
        -ETU uniquement
            -Si le ETU n'est pas dans la base , on demande un champ nom et inscription automatique
### Bootstrap
### Code Dynamique
## function.php