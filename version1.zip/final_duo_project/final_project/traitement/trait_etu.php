<?php
session_start();
include("../function/function.php");

if (!empty($_POST["etu"])) {
    $etu = $_POST["etu"];
    $resultat = get_etu($etu);

    if (!empty($resultat)) {
        $_SESSION["etu"] = (int)$etu;
        header("Location: ../page/accueil.php");
        exit;
    } else {
        add_etu($etu);
        $_SESSION["etu"] = (int)$etu;
        header("Location: ../page/login.php?sign=1");
        exit;
    }
} elseif (!empty($_POST["nom"])) {
    if (!empty($_SESSION["etu"])) {
        sign_up_etu($_POST["nom"], $_SESSION["etu"]);
        header("Location: ../page/accueil.php");
        exit;
    } else {
        header("Location: ../page/login.php");
        exit;
    }
} else {
    header("Location: ../page/login.php");
    exit;
}
