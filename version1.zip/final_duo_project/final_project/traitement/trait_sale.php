<?php
session_start();
include("../function/function.php");

if (!empty($_POST["id_produit_membre"]) && !empty($_POST["sale"])) {
    $id_produit_membre = (int)$_POST["id_produit_membre"];
    $sale = (int)$_POST["sale"];

    Saling_my_produits($id_produit_membre, $sale);
}

header("Location: ../page/vendre.php");
exit;
